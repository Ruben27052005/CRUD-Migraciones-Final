package com.example.demo.Controller;

import com.example.demo.Entity.Usuario;
import com.example.demo.Service.UsuarioController;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.sql.SQLException;

@Controller
@RequestMapping("/usuario")
public class ControllerVistas {
UsuarioController usuarioController = new UsuarioController();

    public ControllerVistas() throws SQLException {
    }


    @GetMapping("/form")
    public String gettingform(Model model) {
        model.addAttribute("usuario", new Usuario());
        return "./usuario/Formulario";
    }

    @GetMapping("/list")
    public String list(Model model) {
        try {
            model.addAttribute("entidades", usuarioController.obtenerUsuarios());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return "./usuario/vistalistar";
    }
    // Página para listar entidades
//    @GetMapping("/")
//    public String listarEntidades() {
//        return "./usuario/vistalistar";
//    }

    // Página para editar una entidad existente
    @PostMapping("/registrar")
    public String registrar(@ModelAttribute Usuario usuario) throws SQLException {
        usuarioController.agregarUsuario(usuario); // Asumo que tienes un método para agregar usuarios en UsuarioController
        return "redirect:/usuario/list"; // Después de registrar, redirige a la lista de usuarios
    }

    // Lógica para eliminar una entidad
    // Implementar método y ruta correspondiente si deseas tener funcionalidad de eliminación
    @GetMapping("/eliminar")
    public String SubmitB (@RequestParam("codusuario") int id, Model model){
        String valorfinal="redirect:/usuario/";
        try {
            model.addAttribute("clientes",usuarioController.eliminarUsuario(id));
        } catch (SQLException ex) {
            valorfinal="error";
        }
        return valorfinal;
    }
}
